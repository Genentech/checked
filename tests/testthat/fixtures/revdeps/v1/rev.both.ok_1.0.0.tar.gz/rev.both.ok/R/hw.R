#' Hello world wrapper
#'
#' @export
hello_world_wrapper <- function() {
  pkg.ok.error::hello_world()
}
