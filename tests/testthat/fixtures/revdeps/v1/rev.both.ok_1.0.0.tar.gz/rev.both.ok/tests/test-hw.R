library(rev.both.ok)
stopifnot(hello_world_wrapper() == "hello world")
