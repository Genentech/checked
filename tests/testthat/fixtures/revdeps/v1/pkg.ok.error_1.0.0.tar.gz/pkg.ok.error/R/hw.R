#' Hello world 
#'
#' @export
hello_world <- function() {
  "hello world"
}

#' Hello world loud
#'
#' @export
hello_world_loud <- function() {
  "hello world!"
}
