library(pkg.ok.error)
stopifnot(hello_world() == "hello world")
stopifnot(hello_world_loud() == "hello world!")
