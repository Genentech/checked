#' Hello world loud wrapper
#'
#' @export
hello_world_loud_wrapper <- function() {
  pkg.ok.error::hello_world_loud()
}
