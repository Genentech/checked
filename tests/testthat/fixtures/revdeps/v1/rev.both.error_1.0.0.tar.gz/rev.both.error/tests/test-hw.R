library(rev.both.error)
stopifnot(hello_world_loud_wrapper() == "hello world!")
