  library(pkg.none)
  stopifnot(hello_world() == "hello world")
